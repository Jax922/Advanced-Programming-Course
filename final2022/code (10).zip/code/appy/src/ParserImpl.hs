-- Put yor parser implementation in this file
module ParserImpl where

import Definitions
-- import ReadP or Parsec

parseSpec :: String -> EM (String, EGrammar)
parseSpec = undefined
