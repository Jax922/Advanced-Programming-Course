-- Skeleton file for Boa Parser.

module BoaParser (ParseError, parseString) where

import Text.ParserCombinators.ReadP
import Control.Applicative ((<|>))
import Data.Char


import BoaAST
-- add any other other imports you need


data ParseError = PE String -- you may replace this
    deriving(Eq, Show) -- ?
-- instance here

--------- parse 
program :: ReadP Program
program =
    trim stmts

-- ----------------------------stmts\stmt parse
stmts :: ReadP [Stmt]
stmts =
    do
        st <- stmt
        skipSpaces
        string ";"
        skipSpaces
        sts <- stmts
        skipSpaces
        return (st:sts)
    <|>
    do
        st <- stmt
        skipSpaces
        return [st]

stmt :: ReadP Stmt
stmt =
    do
        skipSpaces
        i <- ident
        skipSpaces
        string "="
        skipSpaces
        e <- expr
        skipSpaces
        return (SDef i e)
    <|>
    do
        skipSpaces
        e <- expr
        skipSpaces
        return (SExp e)
-- -----------------------------ident parse 
ident :: ReadP String
ident = do
    fstC <- count 1 isNotDigit
    restC <- munch(\c -> isAlpha c || c == '_' || isDigit c)
    if isReservedWords (fstC ++ restC)
        then pfail -- "can not be reserve words"
    else
        return (fstC ++ restC)

isNotDigit :: ReadP Char
isNotDigit =
    satisfy (\c -> isLetter c || c  == '_')

isReservedWords :: String -> Bool
isReservedWords s =
    s `elem` ["None", "True", "False", "for", "if", "in", "not"]

-- ---------------------------- numConst parse
numConst :: ReadP Exp
numConst = trim (do
    (oneNum) <|> (moreTwoNum))

oneNum :: ReadP Exp
oneNum = trim (do
    fstC <- count 1 isOneDigit
    skipSpaces
    return (Const (IntVal (read fstC))))

moreTwoNum :: ReadP Exp
moreTwoNum = trim (do
    fstC <- (string "-") <|> (string "+") <|> count 1 isOneDigit
    spaces <- munch(\c -> isSpace c)
    endC <- munch1(\c -> isDigit c)
    skipSpaces
    if (fstC == "0" || fstC == "+") && endC /= ""
        then pfail -- inlegal number
    else
        if any isSpace spaces
            then pfail -- some whitespace in number
        else
            return (Const (IntVal (read (fstC ++ endC)))))

isOneDigit :: ReadP Char
isOneDigit =
    satisfy isDigit

-- -------------------------- stringConst parse
stringConst :: ReadP Exp
stringConst = trim (do
    string "'"
    s <- many $ satisfy isAscii
    string "'"
    skipSpaces
    if illegalString s
        then pfail
    else
        return (Const (StringVal (convertString(s)))))
    -- return (Const (StringVal (inside)))

-- escape  = '\\' ($printable | 'x' $hexdig+ | 'o' $octdig+ | $digit+)
illegalString :: String -> Bool
illegalString s =
    (s /= "" && (head s) == '\\') || elem s ["\DEL", "\n", "\t", "\NUL", "'", "''"]

-- takeString :: ReadP Exp
-- takeString = trim $ (do


-- 
convertString :: String -> String
convertString "" = ""
convertString (x:xs)
    | x == '\\' = case head xs of
                    'n' -> '\n' : convertString (tail xs)
                    '\n' -> convertString $ tail xs
                    '\\' -> '\\' : convertString (tail xs)
                    _ -> convertString xs
    | otherwise = x : convertString xs

-- -----------------------None\True\False\not parse
noneP :: ReadP Exp
noneP = trim (do
    string "None"
    return (Const NoneVal))

trueP :: ReadP Exp
trueP = trim (do
    string "True"
    skipSpaces
    return (Const TrueVal))

falseP :: ReadP Exp
falseP = trim (do
    string "False"
    skipSpaces
    return (Const FalseVal))

--"not" Expr
notP :: ReadP Exp
notP = trim (do
    string "not"
    skipSpaces
    e <- expr
    skipSpaces
    return (Not e))
-- ----------------------- ‘(’ Expr ‘)’ 
nest :: ReadP Exp
nest = trim (do
    string "("
    skipSpaces
    e <- expr
    skipSpaces
    string ")"
    skipSpaces
    return e)

-- -----------------------expr parse
-- Expr :== expr'' Oper Expr | expr''
-- expr'' := ... rest of Expr except the Oper

-- Expr :== expr' || 非oper
-- expr' = Exp LExp'
-- LExp' = oper expr'
-- CExpr = Exp | Exp reop Exp


-- Expr ::= "not" Expr | expr'
-- expr' ::= expr'' Oper expr' | expr''
-- expr''' :: = "(" Expr ")" | ident "(" Exprz ")" | "[" Exprz "]" | "[" Expr ForClause Clausez "]" |  numConst | stringConst | "None" | "True" | "False" | ident
-- Oper ::= "==" | "!=" | "<" | "<=" | ">" | ">=" | "in" | "not" "in" | ArithOper
-- ArithOper  ::= "+" | "-" | FactOper
-- FactOper ::= "*" | "//" | "%"  

-- E ::= TE' | "-" TE'
-- E' ::= "+" TE' | "-" TE' | ε
-- T ::= num | "(" E ")

-- Expr ::= "not" Expr | expr'
-- expr' ::= expr'' LExpr |  expr'' COper expr'
-- LExpr = LOper expr' LExpr | ε
-- LOper = ArithOper | FactOper
-- ArithOper = "+" | "-"
-- FactOper = "*" | "//" | "%" 
-- COper = "==" | "!=" | "<" | "<=" | ">" | ">=" | "in" | "not" "in" 
-- expr'' :: = "(" Expr ")" | ident "(" Exprz ")" | "[" Exprz "]" | "[" Expr ForClause Clausez "]" |  numConst | stringConst | "None" | "True" | "False" | ident

-- Expr ::= "not" Expr | expr' 
-- expr' =  T Eopt |  expr'' COper expr' 
-- Eopt = ArithOper T Eopt
-- T :: expr'' Topt
-- Topt :: FactOper expr'' Topt
-- expr'' :: = "(" Expr ")" | ident "(" Exprz ")" | "[" Exprz "]" | "[" Expr ForClause Clausez "]" |  numConst | stringConst | "None" | "True" | "False" | ident

-- Expr ::= "not" Expr | expr'
expr :: ReadP Exp
expr = trim (do
        (notP <|> expr'))

-- Topt :: FactOper expr' Topt
tOpt :: Exp -> ReadP Exp
tOpt e = do
    fop <- lOp
    e' <- expr''
    t <- tOpt e'
    return (Oper (getOp fop) e t)
-- T :: expr' Topt
tT :: ReadP Exp
tT = do
    e' <- expr''
    tOpt e'

-- Eopt = ArithOper T Eopt
eOpt :: Exp -> ReadP Exp
eOpt e = do
    aop <- lOp
    t <- tT
    e' <- eOpt t
    return (Oper (getOp aop) e e')

-- expr' ::= expr'' LExpr |  expr'' COper expr'
-- expr' :: ReadP Exp
-- expr' =
--     do
--         e'' <- expr''
--         lExpr e''
--     <|>
--     do
--          e'' <- expr''
--          cop <- cOP
--          getComplexOp cop e'' <$> expr'

-- expr' =  T Eopt |  expr'' COper expr' | expr''
expr' :: ReadP Exp
expr' = 
    do
        t <- tT
        e <- eOpt t
        return e
    <|>
    do
        e'' <- expr''
        cop <- cOP
        e' <- expr'
        return (getComplexOp cop e'' e')
    <|>
    do
        e'' <- expr''
        return e''

-- LExpr = LOper expr' LExpr
-- x + y - z
-- y+z*u
lExpr :: Exp -> ReadP Exp
lExpr e = do
    s <- lOp
    e' <- expr'
    le <- lExpr (Oper (getOp s) e e')
    return  le
    <|>
    return e

-- expr'' :: = "(" Expr ")" | ident "(" Exprz ")" | "[" Exprz "]" | "[" Expr ForClause Clausez "]" |  numConst | stringConst | "None" | "True" | "False" | ident
expr'' :: ReadP Exp
expr'' = trim (do
    (listForClauseP <|> identExprz <|> nest <|> listExprz
        <|>numConst <|> varP <|> stringConst
            <|> noneP <|> trueP <|> falseP  ))

-- ------------------ident (var parse)
varP :: ReadP Exp
varP = trim (do
    -- skipSpaces
    i <- ident
    skipSpaces
    return (Var i))

-- ------------------oper parse

getOp :: String -> Op
getOp "+" = Plus
getOp "-" = Minus
getOp "*" = Times
getOp "//" = Div
getOp "%" = Mod
getOp "==" = Eq
getOp "<" = Less
getOp ">" = Greater
getOp "in" = In

getComplexOp :: String -> Exp -> Exp -> Exp
getComplexOp s e1 e2
    | s == "!=" = Not (Oper Eq e1 e2)
    | s == "<=" = Not (Oper Greater e1 e2)
    | s == ">=" = Not (Oper Less e1 e2)
    | s == "notin" = Not (Oper In e1 e2)
    | s == "not\tin" = Not (Oper In e1 e2)
    | s == "not in" = Not (Oper In e1 e2)
    |otherwise = Oper (getOp s) e1 e2

-- LOper = ArithOper | FactOper
lOp :: ReadP String
lOp =
    ( arithmeticOp <++ factOp )

--cop
cOP ::ReadP String
cOP = compareOp

-- ArithOper = "+" | "-"
arithmeticOp :: ReadP String
arithmeticOp = do
    string "-" <|> string "+"

-- FactOper = "*" | "//" | "%" 
factOp :: ReadP String
factOp = do
    string "*" <|> string "//" <|> string "%"

compareOp :: ReadP String
compareOp = do
    string ">" <|>  string "==" <|> string "<" <|> string "notin"
            <|> string "in" <|> string "not\tin" <|> string "not in"

--  "x%y-z>(not u)"
-- "x+y-z"

oper :: ReadP Exp
oper = trim (do
    e1 <- expr''
    skipSpaces
    op <- compareOp <++ arithmeticOp
    skipSpaces
    e2 <- expr
    skipSpaces
    return (getComplexOp op e1 e2))

-- ----------- exprs\exprz parse
exprs :: ReadP [Exp]
exprs =
    do
        e <- expr
        return [e]
    <|>
    do
        e<-expr
        string ","
        es<-exprs
        return (e:es)

exprz :: ReadP [Exp]
exprz =
    exprs <|> return []

-- ---------- ident ‘(’ Exprz ‘)’
identExprz :: ReadP Exp
identExprz = trim (do
    i <- ident
    skipSpaces
    string "("
    skipSpaces
    ez <- exprz
    skipSpaces
    string ")"
    skipSpaces
    return (Call i ez))

-- ---------- ‘[’ Exprz ‘]’
listExprz :: ReadP Exp
listExprz = trim (do
    string "["
    skipSpaces
    ez <- exprz
    skipSpaces
    string "]"
    skipSpaces
    return (List ez))

-- ---------- ‘[’ Expr ForClause Clausez ‘]’
listForClauseP :: ReadP Exp
listForClauseP = trim (do
    string "["
    e <- expr
    f <- forClauseP
    c <- clausezP f
    string "]"
    return (Compr e c))

-- ---------- IfClause ::== ‘if’ Expr
ifClauseP :: ReadP CClause
ifClauseP = do
    string "if"
    CCIf <$> expr

-- ---------- ForClause ::== ‘for’ ident ‘in’ Expr
forClauseP :: ReadP CClause
forClauseP = trim (do
    string "for"
    skipSpaces
    i <- ident
    skipSpaces
    string "in"
    skipSpaces
    e <- expr
    return (CCFor i e))

-- ---------- Clausez 
clausezP :: CClause -> ReadP [CClause]
clausezP c =
    do
        f <- forClauseP
        c' <- clausezP f
        return (c:c')
    <|>
    do
        i <- ifClauseP
        c' <- clausezP i
        return (c:c')
    <|>
    return [c]

-- -- print function parse
-- printP :: ReadP Exp
-- printP = trim $ (do
--         string "print"
--         skipSpaces

--     )

parseString :: String -> Either ParseError Program
parseString s =
    let res = readP_to_S program s
    in
      if null res || snd (last res) /= ""
        then Left (PE "ParseError")
      else Right (fst (last res))



trim :: ReadP a -> ReadP a
trim e =
    do
        optional skipComment
        e
    <++
    do
        skipSpaces
        e

skipComment:: ReadP String
skipComment =
    do
        skipSpaces
        string "#"
        many $ satisfy isAscii
        string "\n"
    <|>
    do
        skipSpaces
        string "#"
        many $ satisfy isAscii
        string "#"
    <|>
    do
        skipSpaces
        string "#"
        many $ satisfy isAscii

-- removeComment :: String -> String


spacesExp :: ReadP ()
spacesExp =  do
    -- munch isSpace
    many (satisfy isSpace)
    return ()

-- left associative

opp :: ReadP (String -> String -> String)
opp =
    return (\s1 s2 -> "")

pp' :: ReadP String
pp' = do
    string "-" <|> string "+"

-- -- pp :: ReadP String
-- -- pp = 
-- lOp `chainl1` opp = do
--         a <- lOp
--         p' a 
--             where p' a1 = do
--                 o <- opp
--                 a2 <- lOp `chainl1` opp
--                 return (a1 `o` a2)
--                 <|>
--                 return a1

--         -- c2 <- chainr1 lOp opp
--     -- return c1



        -- lOp `chainr1` opp = do
        -- a <- p
        -- p' a 
            -- where p' a1 = do
                    --         o <- opp
                    --         a2 <- p `chainr1` opp
                    --         return (a1 `o` a2)
                    --         <|>
                    --         return a1