-- Do not modify this file. Put your Coder code in CoderImpl
module Coder (pick, solutions, produce) where

import CoderImpl
