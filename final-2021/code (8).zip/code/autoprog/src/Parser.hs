-- Do not modify this file. Put your Parser code in ParserImpl
module Parser (parseStringType, parseStringTDeclz) where

import ParserImpl

